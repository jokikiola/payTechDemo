<?php

namespace App\Http\Controllers\Project;

use App\Http\Controllers\Controller;
use App\Models\Plan;
use App\Models\Product;
use App\Models\Transaction;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class RechargeController extends Controller
{
    //
    public function index()
    {
        return view('project.recharge.index');
    }

    public function fetchTransactions(): JsonResponse
    {
        $transactions = Transaction::with('plan.product.service')->get();
        return response()->json([
            'data' => $transactions,
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $this->validateRequest($request);
        $status = $this->apiCall($request);
        $this->createTransaction($request, $status);
        return response()->json([
            'message' => 'Recharge successful'
        ]);
    }

    private function validateRequest($request)
    {
        $request->validate([
            'service' => 'required',
            'product' => 'required',
            'plan' => 'required',
            'amount' => 'required',
            'telephone' => 'required',
        ], [
            'service.required' => 'Select a service',
            'product.required' => 'Select a product',
            'plan.required' => 'Select Plan',
            'telephone' => 'Enter decoder number or telephone number'
        ]);
    }

    private function createTransaction($request, $status)
    {
        $transaction = new Transaction();
        $transaction->create([
            'plan_id' => $request['plan'],
            'user_id' => 1,
            'amount' => $request['amount'],
            'digit' => $request['telephone'],
            'other_charges' => 0.00,
            'status' => $status,
            'transaction_date' => date('Y-m-d'),
        ]);
    }

    private function apiCall($request)
    {

        return $status = 1;
    }

    /**
     * Fetch plan
     * @param Product $product
     * @return JsonResponse
     */
    public function fetchPlan(Product $product): JsonResponse
    {
        $plans = $product->plan()->get();
        return response()->json([
            'data' => $plans
        ]);

    }

    /**
     * fetch plan information such as price
     * @param Plan $plan
     * @return JsonResponse
     */
    public function fetchPrice(Plan $plan): JsonResponse
    {
        return response()->json([
            'data' => $plan
        ]);
    }
}
