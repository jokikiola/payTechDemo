<script>
    function errorNotification(message) {
        $(function () {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000
            });
            Toast.fire({
                type: 'error',
                title: message
            })
        });
    }
</script>
<?php /**PATH C:\wamp64\www\pay\resources\views/project/global/notification/_error.blade.php ENDPATH**/ ?>